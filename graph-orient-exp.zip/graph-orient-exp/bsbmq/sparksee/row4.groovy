 import com.tinkerpop.blueprints.impls.sparksee.*;
s = new SparkseeGraph("/tmp/182055849");
s.loadGraphML("/home/ironman/Desktop/EDBT-2018-Experiments/Data/bsbm/bsbm1m.graphml");
s.createKeyIndex("productID", Vertex.class)
s.createKeyIndex("label_n", Vertex.class)
s.createKeyIndex("type", Vertex.class)
s.createKeyIndex("productTypeID", Vertex.class)
s.createKeyIndex("reviewerID", Vertex.class)

for(i in 1..10) {
	q = System.currentTimeMillis();
	tt = s.V().has("productID", 343).map("label_n")
	println (System.currentTimeMillis() - q)
}
System.exit(0);
