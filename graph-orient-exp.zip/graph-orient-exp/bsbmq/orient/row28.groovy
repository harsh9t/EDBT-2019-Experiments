s = new OrientGraph("memory:/tmp/606099337");
s.loadGraphML("/home/ironman/Desktop/EDBT-2018-Experiments/Data/bsbm/bsbm1m.graphml");
s.createKeyIndex("productID", Vertex.class)
s.createKeyIndex("label_n", Vertex.class)
s.createKeyIndex("type", Vertex.class)
s.createKeyIndex("productTypeID", Vertex.class)
s.createKeyIndex("reviewerID", Vertex.class)

q = System.currentTimeMillis();
tt = s.V().has("type", "review").out().has("type", "product").groupCount{it.productID}.cap()
println (System.currentTimeMillis() - q)
System.exit(0);
