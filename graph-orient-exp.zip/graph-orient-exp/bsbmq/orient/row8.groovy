s = new OrientGraph("memory:/tmp/248819697");
s.loadGraphML("/home/ironman/Desktop/EDBT-2018-Experiments/Data/bsbm/bsbm1m.graphml");
s.createKeyIndex("productID", Vertex.class)
s.createKeyIndex("label_n", Vertex.class)
s.createKeyIndex("type", Vertex.class)
s.createKeyIndex("productTypeID", Vertex.class)
s.createKeyIndex("reviewerID", Vertex.class)

q = System.currentTimeMillis();
tt = s.V().has("productID", 343).inE().outV().has("type", "review").map("Rating_1")[0..1]
println (System.currentTimeMillis() - q)
System.exit(0);
