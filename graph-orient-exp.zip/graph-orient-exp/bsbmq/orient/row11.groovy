s = new OrientGraph("memory:/tmp/280778160");
s.loadGraphML("/home/ironman/Desktop/EDBT-2018-Experiments/Data/bsbm/bsbm1m.graphml");
s.createKeyIndex("productID", Vertex.class)
s.createKeyIndex("label_n", Vertex.class)
s.createKeyIndex("type", Vertex.class)
s.createKeyIndex("productTypeID", Vertex.class)
s.createKeyIndex("reviewerID", Vertex.class)

q = System.currentTimeMillis();
tt = s.V().has("type", "reviewer").has("reviewerID", 86).outE().inV().has("Rating_1").outE().inV().map("productID")
println (System.currentTimeMillis() - q)
System.exit(0);
