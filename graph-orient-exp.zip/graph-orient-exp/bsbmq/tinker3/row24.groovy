
x = TinkerGraph.open();
x.io(gryo()).readGraph("/home/ironman/Desktop/EDBT-2018-Experiments/Data/northwind/northwind.kryo");
x.createIndex("productID", Vertex.class)
x.createIndex("label_n", Vertex.class)
x.createIndex("type", Vertex.class)
x.createIndex("productTypeID", Vertex.class)
x.createIndex("reviewerID", Vertex.class)

g = x.traversal();
for (i in 1..10) {
	q = System.currentTimeMillis();
	tt = g.V().or( __.has('productID',343).values('ProductPropertyTextual_1','ProductPropertyTextual_2'), __.has('productID',350).values('ProductPropertyNumeric_1')).values("ProductPropertyTextual_1", "ProductPropertyTextual_2", "ProductPropertyNumeric_1")
	println (System.currentTimeMillis() - q)
}
