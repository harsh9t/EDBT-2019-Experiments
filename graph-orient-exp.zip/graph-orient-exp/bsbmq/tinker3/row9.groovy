
x = TinkerGraph.open();
x.io(gryo()).readGraph("/home/ironman/Desktop/EDBT-2018-Experiments/Data/northwind/northwind.kryo");
x.createIndex("productID", Vertex.class)
x.createIndex("label_n", Vertex.class)
x.createIndex("type", Vertex.class)
x.createIndex("productTypeID", Vertex.class)
x.createIndex("reviewerID", Vertex.class)

g = x.traversal();
for (i in 1..10) {
	q = System.currentTimeMillis();
	tt = g.V().has("productID").has("label_n").valueMap("productID","label_n").range(0,5)
	println (System.currentTimeMillis() - q)
}
