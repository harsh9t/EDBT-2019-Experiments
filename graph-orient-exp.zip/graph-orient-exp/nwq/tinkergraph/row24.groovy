 import com.tinkerpop.blueprints.impls.sparksee.*;
s = new TinkerGraph("/tmp/472397190");
s.loadGraphML("/home/ironman/Desktop/EDBT-2018-Experiments/Data/northwind/northwind.graphml");
s.createIndex("name", Vertex.class)
s.createIndex("customerId", Vertex.class)
s.createIndex("unitPrice", Vertex.class)
s.createIndex("unitsInStock", Vertex.class)
s.createIndex("unitsOnOrder", Vertex.class)

for(i in 1..10) {
	q = System.currentTimeMillis();
	tt = s.V().has("labelV", "customer").filter{it.customerID=="ALFKI" || it.customerID=="ANTON"}.map("contactName", "phone")
	println (System.currentTimeMillis() - q)
}
System.exit(0);
